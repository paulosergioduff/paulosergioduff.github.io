<?php

function create()

   { 

        include 'crud/create.php';

    }

create();
  

echo  "<br>", $nomedoarquivo;

  ?>