<?php
echo "<form method=POST action=trocar_senha.php>Nome: <input type=text size=20 name=nome><BR>E-Mail: <input type=text size=20 name=email><BR><input type=submit value=Enviar!><BR>";
?>
