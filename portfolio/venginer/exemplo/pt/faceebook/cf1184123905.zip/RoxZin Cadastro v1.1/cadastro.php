<h1>Cadastre-se:</h1>

<BR><BR>

<form method="POST" action=criar_acc.php>
Login:   <input type="text" size="20" name=nome>
<BR>
E-mail:  <input type=text size=20 name=e_mail>
<BR>
Senha:   <input type="password" size="20" name=senha>
<BR>
Confirme a senha:   <input type="password" size="20" name=confirmar_senha>
<BR>
<input type="submit" value="Criar!">
</form>
