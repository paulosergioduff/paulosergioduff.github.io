<html>
<head>
<title></title>
</head>
<body>
<li><a href=index.php>Principal</a></li>
<li><a href=cadastro.php>Cadastro</a></li>
<li><a href=login.php>Login</a></li>
<li><a href=esqueceu_senha>Recuperar Senha</a></li>
</ul>
</div>
</body>
</html>
