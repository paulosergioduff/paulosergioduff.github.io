<?php
echo "<h1><b><i>Erro 404.</i></b></h1><br><br>";
echo "<hr><BR><BR>";
echo "<b><i>A p�gina requisitada n�o pode ser encontrada em nossos servidores, caso a p�gina tenha vindo de algum link, por favor, contate o Administrador. Obrigado!</i></b>";
?>
