<?php

include 'essencial.php';
include 'headers.php';
include 'bootstrap.php';

?>
<meta charset="UTF-8">
</head>

</body>
<?php include 'navbar.php'; ?>
<hr>

<?php include 'idata/buscando.php'; ?> 


<?php include 'footer.php'; ?>



