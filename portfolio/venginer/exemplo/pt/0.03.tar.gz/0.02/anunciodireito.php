<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Retangulo teste -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-8136135240991918"
     data-ad-slot="7087200190"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
