var item=new Array();

// "Endere�o","T�tulo","Palavras-chave","Descri��o"

item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");

item[item.length]=new Array("http://www.superhosst.com.br","","Hospedagem em nuvem","A mais nova forma d computa��o","host pedraa pau");
