var item=new Array();

// "Endereço","Título","Palavras-chave","Descrição"

item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");

item[item.length]=new Array("watch?v=jNQXAC9IVRw",""," Me at the zoo<br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg><br>"," The first video on YouTube..","");

item[item.length]=new Array("uO5gfQRdzs0",""," De Homem a Penha não tem Pena<br><img src=http://img.youtube.com/vi/uO5gfQRdzs0/default.jpg>"," 286 referências investigando a relação de gênero em violência doméstica: http://csulb.edu/~mfiebert/assault.htm Matéria sobre a pesquisa no Brasil que conclu....","");

item[item.length]=new Array("WodF95r8Ay8&n=0",""," 15/03: Eu Não Vou<br><img src=http://img.youtube.com/vi/WodF95r8Ay8/default.jpg>"," Amanhã é dia de protesto, e desse eu não pretendo participar. ----------- Música: Wallpaper/Modern Jazz Samba por Kevin MacLeod (incompetech.com). Licensed u....","");

item[item.length]=new Array("watch?v=u8id9g-Ct6s&n=0",""," Os Cavaleiros do Zodiaco Filme 2 : A Grande Batalha dos Deuses<br><img src=http://img.youtube.com/vi/u8id9g-Ct6s/default.jpg>"," Sinopse: Odin é o deus supremo dos deuses da mitologia nórdica. Senhor da mágia e da sabedoria, Odin é detentor da lendária espada Balmung. Possui como monta....","");

item[item.length]=new Array("watch?v=CpseG8Tif2c&n=0","","<a href=watch?v=CpseG8Tif2c> 6 PREVISÕES QUE OS SIMPSONS FIZERAM (E ACERTARAM)</a><br><img src=http://img.youtube.com/vi/CpseG8Tif2c/default.jpg>"," Inscreva-se no canal: http://goo.gl/En1Gmd Assista outras listas: http://goo.gl/IG7nqk Fanpage: http://goo.gl/ubF733 Uma vez acabei me perdendo em uma feira ....","");

item[item.length]=new Array("watch?v=k5hmwk-Vv30&n=0","","<a href=watch?v=k5hmwk-Vv30> JASPION EP 21 PARTE 3</a><br><img src=http://img.youtube.com/vi/k5hmwk-Vv30/default.jpg>","Descrição Teste","");

item[item.length]=new Array("watch?v=k5hmwk-Vv30&n=0","","<a href=watch?v=k5hmwk-Vv30> JASPION EP 21 PARTE 3</a><br><img src=http://img.youtube.com/vi/k5hmwk-Vv30/default.jpg>","Descrição Teste 2 testando","");

item[item.length]=new Array("watch?v=34toH08IRwU&n=0","","<a href=watch?v=34toH08IRwU> GTA V - Entrando em QUATRO BURACOS, Corrida NOVA</a><br><img src=http://img.youtube.com/vi/34toH08IRwU/default.jpg>"," Loja Parceira - Playstation 4, XBOX ONE, games e acessórios: http://bit.ly/1qZjQvD (cupom com 5% de desconto, aproveitem!) INSCREVA-SE NO CANAL - http://goo.....","");

//<img src=http://img.youtube.com/vi/-79uIRQiAFM/default.jpg>
item[item.length]=new Array("watch?v=-79uIRQiAFM&n=0","olá mundo","<a href=watch?v=-79uIRQiAFM> How BIG is Google?</a><br>","&#34; MUCH more where this came from. Subscribe to see it! Video Editing: http://www.cfnstudios.com ColdfusTion Android Launcher: https://play.google.com/store/app....","");

item[item.length]=new Array("watch?v=0M2xrMYgrtY&n=0","","<a href=watch?v=0M2xrMYgrtY> OS CAVALEIROS DO ZODIACO - O FILME PROLOGO DO CEU-DUBLADO</a><br><img src=http://img.youtube.com/vi/0M2xrMYgrtY/default.jpg>","CDZ","");

item[item.length]=new Array("watch?v=-hdSoy20W_U&n=0","","<a href=watch?v=-hdSoy20W_U> Os Cavaleiros do Zodiaco - A Lenda dos Defensores de Atena</a><br><img src=http://img.youtube.com/vi/-hdSoy20W_U/default.jpg>","","");

item[item.length]=new Array("watch?v=jNQXAC9IVRw&n=0","","<a href=watch?v=jNQXAC9IVRw>Título</a><br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg><br>Descricao!!!","palavra chave","");



item[item.length]=new Array("watch?v=-79uIRQiAFM&n=0","","<a href=watch?v=-79uIRQiAFM> How BIG is Google?</a><br><img src=http://img.youtube.com/vi/-79uIRQiAFM/default.jpg>","","");

item[item.length]=new Array("watch?v=FBdrMCucTt4&n=0","","<a href=watch?v=FBdrMCucTt4> Jaspion (1985) Dublado - Ep. 33 [Parte 02]</a><br><img src=http://img.youtube.com/vi/FBdrMCucTt4/default.jpg>"," Jaspion (1985) Kyojuu Tokusou Jaspion (巨獣特捜ジャスピオン, Kyojū Tokusō Jasupion?, traduzido como Investigador de Monstros Juspion, e lançado no Brasil sob o título ....","key");

item[item.length]=new Array("watch?v=EI6AuSO-R10&n=0","","<a href=watch?v=EI6AuSO-R10> Alemão neurótico - Legendado português - novo</a><br><img src=http://img.youtube.com/vi/EI6AuSO-R10/default.jpg>Publicaado em 20-03-2015-16-08-28","key 2"," Garoto neurótico jogando Unreal Tournament..");

item[item.length]=new Array("watch?v=jNQXAC9IVRw&n=0","","<a href=watch?v=jNQXAC9IVRw> Me at the zoo</a><br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg>Publicaado em 20-03-2015-17-47-42","teste"," The first video on YouTube..");

item[item.length]=new Array("watch?v=-79uIRQiAFM&n=0","","<a href=watch?v=-79uIRQiAFM> How BIG is Google?</a><br><img src=http://img.youtube.com/vi/-79uIRQiAFM/default.jpg>Publicaado em 20-03-2015-17-51-15",""," MUCH more where this came from. Subscribe to see it! Video Editing: http://www.cfnstudios.com ColdfusTion Android Launcher: https://play.google.com/store/app....");

item[item.length]=new Array("watch?v=L6B_dNfL8ew&n=0","","<a href=watch?v=L6B_dNfL8ew> Os 5 Piores Jogos do PS2 [Canal 90]</a><br><img src=http://img.youtube.com/vi/L6B_dNfL8ew/default.jpg>Publicaado em 20-03-2015-18-07-57",""," Veja mais vídeo da série &#34;5 Piores Jogos&#34;: https://www.youtube.com/playlist?list=PLzSxQPt-zF5l2D6wdR9sUmd-L_IV5c8bz Clique em &#34;Mostrar mais&#34; para desbloquear....");

item[item.length]=new Array("watch?v=opji5DgE_nQ&n=0","","<a href=watch?v=opji5DgE_nQ&u=> Dragon Ball Z: Light of Hope - Pilot</a><br><img src=http://img.youtube.com/vi/opji5DgE_nQ/default.jpg>Publicaado em 20-03-2015-18-13-01",""," DONATE HERE FOR EPISODE 2: http://www.robotunderdog.com/donate -- Dragon Ball Z: Light of Hope - Pilot Episode-- SUBSCRIBE! Hope is worth fighting for. In Dr....");

item[item.length]=new Array("watch?v=QrKuxNY3OGc&n=0","","<a href=watch?v=QrKuxNY3OGc&u=00000000001> Herbalife, Góticos e &#34;Síumes&#34;</a><br><img src=http://img.youtube.com/vi/QrKuxNY3OGc/default.jpg>Publicaado em 20-03-2015-18-15-58",""," Quer que meu trabalho aqui continue? Seja o meu patrão! http://www.patreon.com/izzynobre As aberturas do canal são feitas pelo Murilo Almeida. Prestigiem o t....");

item[item.length]=new Array("watch?v=0M2xrMYgrtY&n=0","","<a href=watch?v=0M2xrMYgrtY&u=00000000001> OS CAVALEIROS DO ZODIACO - O FILME PROLOGO DO CEU-DUBLADO</a><br><img src=http://img.youtube.com/vi/0M2xrMYgrtY/default.jpg>Publicaado em 20-03-2015-22-51-20","key"," Quinto filme da franquia Cavaleiros do zodíaco");



item[item.length]=new Array("watch?v=ey9bTshV308&n=0","","<a href=watch?v=ey9bTshV308&u=00000000001> 2 O Método Científico e os Tipos de Pesquisa</a><br><img src=http://img.youtube.com/vi/ey9bTshV308/default.jpg>Publicaado em 21-03-2015-00-02-56",""," .");
