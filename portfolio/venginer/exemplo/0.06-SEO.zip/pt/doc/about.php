<hr>
<center>

<div class="container">

<div class="hero-unit">
<p>    No dia 17 de março de 2015, é inaugurado o Venginer.com.
Um site agregador de vídeos focados na comunidade Vlog/<b>P</b>rodutor <b>O</b>riginal de <b>C</b>onteúdo (OPC/POC). Com o objetivo de facilitar a divulgação de vídeos de produtores independentes, o site agrega recursos de sites poderosos e consagrados como o ©Youtube, ©Facebook, ©Google e em breve (após o término desta redação) ©Twitter.
</p>
<p>Fundado por Paulo Sérgio Duff, em Belford Roxo/Rio de janeiro, o site conta com inicialmente 78 vídeos indexados de clássicos na internet. Os recursos variam desde comentários no facebook, até criação de galerias personalizadas de conteúdo específico da preferência do usuário.
</div>

</div>
<br>
</center>
