var item=new Array();

// "Endere�o","T�tulo","Palavras-chave","Descri��o"

item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");
item[item.length]=new Array("http://www.brdesign.net","","T�tulo<br><img src=http://img.youtube.com/vi/jNQXAC9IVRw/default.jpg>","Descri��o: cria��o de sites desenvolvimento asp javascript flash scripts web homepages internet intranet","Especializado em cria��es de websites e solu��es criativas pra internet e intranet.");
item[item.length]=new Array("http://www.mundoplaystation.kit.net","","Mundo Playstation","games v�deo-games jogos playstation","Site de games voltado ao console playstation.");
item[item.length]=new Array("http://www.buscaon-line.rg3.net","","Busca On-line","busca sites buscador internet","Site de busca dividido em categorias.");
item[item.length]=new Array("http://www.e-dominios.com.br/?from=5301","","E-Dom�nios","registro dom�nios sites","Querendo registrar seu dom�nio. Visite-nos, apenas 39,90 anuais");
