<?php 

error_reporting(0);
ini_set(“display_errors”, 0 );

// E_ALL ^ E_WARNING
// E_ERROR | E_PARSE |  
// ini_set('default_charset','UTF-8');
date_default_timezone_set("America/Sao_Paulo");

?>