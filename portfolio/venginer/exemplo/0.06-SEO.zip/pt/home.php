<?php

include 'essencial.php';
include 'staticheader.php';
include 'headers.php';
include 'bootstrap.php';


?>

</head>

</body>
<?php include 'navbar.php'; ?>

<center>
<div class="container">



<div class='row'>

<div class='span4'>
          <a href=watch?v=gx-NLPH8JeM&u=00000000001&o=h><h4>"Little Superstar"</h4>
          <p><img src='http://img.youtube.com/vi/gx-NLPH8JeM/default.jpg'></a></p>
          <p><a class='btn' href='watch?v=gx-NLPH8JeM&u=00000000001&o=h'>Assistir</a></p>
       </div>

<div class='span4'>
          <a href=watch?v=BEtIoGQxqQs&u=00000000001&o=h><h4> afro ninja</h4>
          <p><img src='http://img.youtube.com/vi/BEtIoGQxqQs/default.jpg'></a></p>
          <p><a class='btn' href='watch?v=BEtIoGQxqQs&u=00000000001&o=h'>Assistir</a></p>
       </div>

<div class='span4'>
  <a href=watch?v=ZZ5LpwO-An4&u=00000000001&o=h><h4> HEYYEYAAE</h4>
          <p><img src='http://img.youtube.com/vi/ZZ5LpwO-An4/default.jpg'></a></p>
          <p><a class='btn' href='watch?v=ZZ5LpwO-An4&u=00000000001&o=h'>Assistir</a></p>
       </div>

<div class='span4'>
          <a href=watch?v=rvYZRskNV3w&u=00000000001&o=h><h4> This is Sparta!</h4>
          <p><img src='http://img.youtube.com/vi/rvYZRskNV3w/default.jpg'></a></p>
          <p><a class='btn' href='watch?v=rvYZRskNV3w&u=00000000001&o=h'>Assistir</a></p>
       </div>

<div class='span4'>
          <a href=watch?v=ettaeKZHAwA&u=00000000001&o=h><h4>Seu Madruga Will Go On</h4>
          <p><img src='http://img.youtube.com/vi/ettaeKZHAwA/default.jpg'></a></p>
          <p><a class='btn' href='watch?v=ettaeKZHAwA&u=00000000001&o=h'>Assistir</a></p>
       </div>




</div>


</center>


<?php include 'footer.php'; ?>