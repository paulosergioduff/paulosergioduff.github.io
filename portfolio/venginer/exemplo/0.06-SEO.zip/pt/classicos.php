var item=new Array();

// "Endereço","Título","Palavras-chave","Descrição"

//item[item.length]=new Array("http://www.biritiba.com.br","","BM Online","biritiba cidade online","Site da cidade de Biritiba Mirim-sP");

item[item.length]=new Array("watch?v=UTp2jwC_KeM&n=0","","<a href=watch?v=UTp2jwC_KeM&u=> Banco do Brasil - Aulão de Informática - Aula 01 - Linux</a><br><img src=http://img.youtube.com/vi/UTp2jwC_KeM/default.jpg>Publicaado em 23-03-2015-10-45-59",""," O Estúdio Aulas foi criado em 2012 com objetivo levar os melhores professores de concursos públicos para a sua casa. A idéia é expandir por todo o Brasil, o ....");
item[item.length]=new Array("watch?v=&n=0","","<a href=watch?v=&u=></a><br><img src=http://img.youtube.com/vi//default.jpg>Publicaado em 23-03-2015-11-19-50","","");

item[item.length]=new Array("watch?v=BEtIoGQxqQs&n=0","","<a href=watch?v=BEtIoGQxqQs&u=BEtIoGQxqQs00000000001h> afro ninja</a><br><img src=http://img.youtube.com/vi/BEtIoGQxqQs/default.jpg>Publicaado em 23-03-2015-11-25-17",""," afro ninja.");

item[item.length]=new Array("watch?v=gx-NLPH8JeM&n=0","","<a href=watch?v=gx-NLPH8JeM&u=gx-NLPH8JeM00000000001h> &#34;Little Superstar&#34;</a><br><img src=http://img.youtube.com/vi/gx-NLPH8JeM/default.jpg>Publicaado em 23-03-2015-11-26-07",""," dancing litte superstar with our big superstar!!!he dance like usher!!yeah!!.");

item[item.length]=new Array("watch?v=ZZ5LpwO-An4&n=0","","<a href=watch?v=ZZ5LpwO-An4&u=ZZ5LpwO-An400000000001h> HEYYEYAAEYAAAEYAEYAA</a><br><img src=http://img.youtube.com/vi/ZZ5LpwO-An4/default.jpg>Publicaado em 23-03-2015-11-27-31",""," MWYAAAH please note I do not own this video.");

item[item.length]=new Array("watch?v=rvYZRskNV3w&n=0","","<a href=watch?v=rvYZRskNV3w&u=rvYZRskNV3w00000000001h> This is Sparta! Last techno remix</a><br><img src=http://img.youtube.com/vi/rvYZRskNV3w/default.jpg>Publicaado em 23-03-2015-11-29-27",""," THIS IS SPARTAAAA...!.");

item[item.length]=new Array("watch?v=ettaeKZHAwA&n=0","","<a href=watch?v=ettaeKZHAwA&u=ettaeKZHAwA00000000001h> ★★★ YTPMV - Seu Madruga Will Go On do mestre3224 ★★★</a><br><img src=http://img.youtube.com/vi/ettaeKZHAwA/default.jpg>Publicaado em 23-03-2015-11-30-44",""," tenho certeza que gostarão de: http://www.youtube.com/watch?v=PzE-TofoECQ NÃO SE INSCREVA SE NÃO CONHECE O MEU CANAL Musica de fundo: Anamanaguchi - My skate....");

item[item.length]=new Array("watch?v=&n=0","","<a href=watch?v=&u=></a><br><img src=http://img.youtube.com/vi//default.jpg>Publicaado em 23-03-2015-11-32-30","","");

item[item.length]=new Array("watch?v=BbX4LB1UcZY&n=0","","<a href=watch?v=BbX4LB1UcZY&u=BbX4LB1UcZY832309410189158> Correção da Prova do Banco do Brasil 2014 - CESGRANRIO - Matemática Financeira - Diogo Miranda</a><br><img src=http://img.youtube.com/vi/BbX4LB1UcZY/default.jpg>Publicaado em 23-03-2015-11-45-27",""," Equipe Aula Móvel realiza a correção da prova do concurso do Banco do Brasil 2014, elaborada pela CESGRANRIO..");

item[item.length]=new Array("watch?v=lSzzrrF-dhs&n=0","","<a href=watch?v=lSzzrrF-dhs&u=lSzzrrF-dhs832309410189158> Comentário da prova do concurso Banco do Brasil 2014 - CESGRANRIO - Língua Portuguesa - Diego Amorim</a><br><img src=http://img.youtube.com/vi/lSzzrrF-dhs/default.jpg>Publicaado em 23-03-2015-11-48-39",""," Equipe Aula Móvel realiza a correção da prova do concurso do Banco do Brasil 2014, elaborada pela CESGRANRIO..");
