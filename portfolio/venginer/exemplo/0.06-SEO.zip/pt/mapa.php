<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=hMtZfW2z9dw&u=00000000001> BED INTRUDER SONG!!! (now on iTunes)</a>
</div>
<br>

<img src=http://img.youtube.com/vi/hMtZfW2z9dw/default.jpg><br>

<div id='data'>
Publicaado em 21-03-2015-11-55-58",
</div>

<br>
<div id='keywords'>
""," Single on iTunes: http://itunes.apple.com/us/album/bed-intruder-song/id386478006 Tribute Album: http://itunes.apple.com/us/album/official-bed-intruder-tribut....");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=&u=></a>
</div>
<br>

<img src=http://img.youtube.com/vi//default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-10-19-17",
</div>

<br>
<div id='keywords'>
"","");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=&u=></a>
</div>
<br>

<img src=http://img.youtube.com/vi//default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-10-22-36",
</div>

<br>
<div id='keywords'>
"","");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=&u=></a>
</div>
<br>

<img src=http://img.youtube.com/vi//default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-10-25-27",
</div>

<br>
<div id='keywords'>
"","");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=&u=></a>
</div>
<br>

<img src=http://img.youtube.com/vi//default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-19-50",
</div>

<br>
<div id='keywords'>
"","");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=BEtIoGQxqQs&u=BEtIoGQxqQs00000000001h> afro ninja</a>
</div>
<br>

<img src=http://img.youtube.com/vi/BEtIoGQxqQs/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-25-17",
</div>

<br>
<div id='keywords'>
""," afro ninja.");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=gx-NLPH8JeM&u=gx-NLPH8JeM00000000001h> &#34;Little Superstar&#34;</a>
</div>
<br>

<img src=http://img.youtube.com/vi/gx-NLPH8JeM/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-26-07",
</div>

<br>
<div id='keywords'>
""," dancing litte superstar with our big superstar!!!he dance like usher!!yeah!!.");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=ZZ5LpwO-An4&u=ZZ5LpwO-An400000000001h> HEYYEYAAEYAAAEYAEYAA</a>
</div>
<br>

<img src=http://img.youtube.com/vi/ZZ5LpwO-An4/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-27-31",
</div>

<br>
<div id='keywords'>
""," MWYAAAH please note I do not own this video.");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=rvYZRskNV3w&u=rvYZRskNV3w00000000001h> This is Sparta! Last techno remix</a>
</div>
<br>

<img src=http://img.youtube.com/vi/rvYZRskNV3w/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-29-27",
</div>

<br>
<div id='keywords'>
""," THIS IS SPARTAAAA...!.");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=ettaeKZHAwA&u=ettaeKZHAwA00000000001h> ★★★ YTPMV - Seu Madruga Will Go On do mestre3224 ★★★</a>
</div>
<br>

<img src=http://img.youtube.com/vi/ettaeKZHAwA/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-30-44",
</div>

<br>
<div id='keywords'>
""," tenho certeza que gostarão de: http://www.youtube.com/watch?v=PzE-TofoECQ NÃO SE INSCREVA SE NÃO CONHECE O MEU CANAL Musica de fundo: Anamanaguchi - My skate....");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=&u=></a>
</div>
<br>

<img src=http://img.youtube.com/vi//default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-32-30",
</div>

<br>
<div id='keywords'>
"","");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=BbX4LB1UcZY&u=BbX4LB1UcZY832309410189158> Correção da Prova do Banco do Brasil 2014 - CESGRANRIO - Matemática Financeira - Diogo Miranda</a>
</div>
<br>

<img src=http://img.youtube.com/vi/BbX4LB1UcZY/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-45-27",
</div>

<br>
<div id='keywords'>
""," Equipe Aula Móvel realiza a correção da prova do concurso do Banco do Brasil 2014, elaborada pela CESGRANRIO..");
</div>
<br>

</div>


<div id=`mapa`>

<div id='titulo'>
"<a href=watch?v=lSzzrrF-dhs&u=lSzzrrF-dhs832309410189158> Comentário da prova do concurso Banco do Brasil 2014 - CESGRANRIO - Língua Portuguesa - Diego Amorim</a>
</div>
<br>

<img src=http://img.youtube.com/vi/lSzzrrF-dhs/default.jpg><br>

<div id='data'>
Publicaado em 23-03-2015-11-48-39",
</div>

<br>
<div id='keywords'>
""," Equipe Aula Móvel realiza a correção da prova do concurso do Banco do Brasil 2014, elaborada pela CESGRANRIO..");
</div>
<br>

</div>


