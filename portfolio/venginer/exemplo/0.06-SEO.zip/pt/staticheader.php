<?php

$titletag = "Venginer.com - Divulgue seus vídeos<";
$descriptiontag = "Site dedicado a divulgação de vídeos de produtores originais na internet, vlogueiros, games, e etc. Serviço integrado com as redes sociais e os mecanismos de busca.";
$keywordstag = "divulgação, blog, vlog, youtube, ytpmv, dailymotion";

?>