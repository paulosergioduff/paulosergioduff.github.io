<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Venginer Responsivo -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8136135240991918"
     data-ad-slot="8703534196"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
