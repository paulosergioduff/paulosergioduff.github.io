<?php

 public class classe
     {

function olafuncao()

  {

echo "Olá função!";

    }



?>