<form action="captag?u=" method="POST">

Link do video:<input type="text" name="videolink" maxlength="43"><br>
<input type="submit" value="Verificar">
