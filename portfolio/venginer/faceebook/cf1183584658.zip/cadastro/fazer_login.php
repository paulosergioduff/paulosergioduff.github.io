<?php
session_start();
$nome = $_POST["nome"];
$senha = $_POST["senha"];
include("passwords/$nome.php");
$nome_md5 = md5($nome);
$senha_md5 = md5($senha);
if ($nome_md5 == $user) {
if ($senha_md5 == $pass){
    $_SESSION["nome"] = "ok";
header("location: logged.php");
}
else{
echo "Senha incorreta! Para voltar para a p�gina de login, clique <a href=login.php>aqui</a>.";
}
}
else{
echo "Usu�rio incorreto! Para voltar para a p�gina de login, clique <a href=login.php>aqui</a>.";
}
?>
